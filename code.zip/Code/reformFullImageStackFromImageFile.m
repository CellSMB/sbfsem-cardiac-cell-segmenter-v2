function img3D = reformFullImageStackFromImageFile(imageFileFolder, fileType, imageSize, view, imgDatatype)
    files = dir(strcat(imageFileFolder,'*.',fileType));
    img = imread(strcat(imageFileFolder,files(1).name));
    img3D = zeros([size(img) imageSize(3)], imgDatatype);
    for i=1:length(files)
        ln = length(files(i).name)-length(fileType);
        sliceNo = int16(str2double(files(i).name(ln-4:ln-1)));
        img = imread(strcat(imageFileFolder,files(i).name));
        
%         if strcmpi(imgDatatype,'logical')   img = img>0;    end
        
        if view==1      img3D(sliceNo,:,:) = img;
        elseif view==2  img3D(:,sliceNo,:) = img;
        elseif view==3  img3D(:,:,sliceNo) = img;        end
    end
end