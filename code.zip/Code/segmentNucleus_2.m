function segmentNucleus_2(imageLocation, ManualSegLocation, outputFolder, outputFilePrefix, filetype)
    mkdir(outputFolder);
    
    % get first and last slice nuber of manual segmentation
    manualSegFiles = dir(strcat(ManualSegLocation,'*.',filetype));
    firstSlice = strsplit(manualSegFiles(1).name,'_');firstSlice = firstSlice{end};
    firstSlice=strsplit(firstSlice,'.');firstSlice = int16(str2double(firstSlice{1}));
    lastSlice = strsplit(manualSegFiles(end).name,'_');lastSlice = lastSlice{end};
    lastSlice=strsplit(lastSlice,'.');lastSlice = int16(str2double(lastSlice{1}));    
    
    % find the largest region of manual segmentation to start from this
    % slice
    startSlice = findLargestManualSegmentedRegion(imageLocation, ManualSegLocation, firstSlice, lastSlice, filetype);
    
    nfiles = length(dir(strcat(imageLocation,'*.',filetype)));
    
    mn_sg = 0; inc=0; pr_sg = 0;
    for i=[startSlice:-1:1 startSlice:nfiles]
        if i==startSlice
            mn_sg = 0; inc=0; pr_sg = 0;
        end
        disp(sprintf('Segmenting Nucleus slice number %04d of %04d',i,nfiles));
        outputFileName = sprintf('%s%s_%04d.%s',outputFolder,outputFilePrefix,i,filetype);
        imgName = dir(strcat(imageLocation,'*',sprintf('%04d',i),'.',filetype));
        if isempty(imgName)==0  img = imread(strcat(imageLocation,imgName.name));  
        else                continue;   end
        mn_sgName = dir(strcat(ManualSegLocation,'*',sprintf('%04d',i),'.',filetype));
        if isempty(mn_sgName)==0    mn_sg = double(imread(strcat(ManualSegLocation,mn_sgName.name))>0);    inc = sum(sum(pr_sg))<sum(sum(mn_sg));      pr_sg = mn_sg; end
        % if the area in the manual segmentation (it could be drived from
        % previous automatic segmentation as well) is less than total area
        % of image/1000 then we stopped segmenting and just writing empty image.   
        if sum(sum(mn_sg))<numel(mn_sg)/1000 mn_sg(:)=0;   imwrite(mn_sg,outputFileName);continue;   end
        
        % Fixing size mismatch if there is.
        if size(img,1)~=size(mn_sg,1)  mn_sg = [mn_sg; zeros(size(img,1)-size(mn_sg,1),size(mn_sg,2))]; end
        if size(img,2)~=size(mn_sg,2)  mn_sg = [mn_sg zeros(size(img,1),size(img,2)-size(mn_sg,2))]; end        
        
        % remove background of image come from machine 
        img = double(removeBackground(img, mn_sg, mn_sg, 0.1));
        % detect area in the image which are not cell.
        [nimg, nonCell] = detectNonCell_2(img, mn_sg>0);

        wn1 = 10;
        % the area which should be nucleus 
        connuc = double(conv2(mn_sg,ones(round(wn1/2),round(wn1/2)),'same')>=floor((wn1*wn1)/4));
        nucleus = zeros(size(img));
        % find the region of interest for nucleus based on edge of the
        % image
        roi = getROIforNucleusBasedEdge_2(nimg, connuc);
        if sum(roi(:))==0 continue; end
        roi = imopen(roi, strel('disk',2));
        nucleus = roi;
%         close all; figure,imshow(imfuse(img, roi),[]);
        imwrite(nucleus,outputFileName);
        mn_sg = double(nucleus);
    end
    
    imageFiles = dir(strcat(imageLocation,'*.',filetype));
    firstSlice = strsplit(imageFiles(1).name,'_');firstSlice = firstSlice{end};
    firstSlice=strsplit(firstSlice,'.');firstSlice = int16(str2double(firstSlice{1}));
    lastSlice = strsplit(imageFiles(end).name,'_');lastSlice = lastSlice{end};
    lastSlice=strsplit(lastSlice,'.');lastSlice = int16(str2double(lastSlice{1}));
    
    nucleus = zeros(size(nucleus));
    
    for i=firstSlice:lastSlice
        outputFileName = sprintf('%s%s_%04d.%s',outputFolder,outputFilePrefix,i,filetype);
        if exist(outputFileName)==0
            imwrite(nucleus,outputFileName);
        end
    end
end