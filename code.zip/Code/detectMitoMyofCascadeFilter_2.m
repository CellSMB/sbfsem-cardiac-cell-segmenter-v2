function [seg] = detectMitoMyofCascadeFilter_2(img, cell, wnR, nonCellInt, slin)
    sz = size(img);
    pad = wnR(end);
       
    img = double(img);
    % Smooth the image except potential mitochondria and myofabrilis regions. 
    img = keepOnlyMytoMyof(img, cell);
    if isempty(img)  seg = zeros(sz(1:2)); return; end
    zero = img==0; img = img+1;
    % Find the non cell region and smooth the regions
    nonCell = getNonCellRegion(img, nonCellInt); wn = round(1.5*slin);
    nonCell = (nonCell - (conv2(double(cell),ones(wn,wn),'same')==wn*wn))>0;
    
    % pad zeros at the left, right, top and bottom for applying accurate
    % average filter.
    nonCell = double(nonCell);
    nonCell = [zeros(pad,sz(2)); nonCell; zeros(pad,sz(2))];
    nonCell = [zeros(size(nonCell,1),pad) nonCell zeros(size(nonCell,1),pad)];
    
    cell = double(cell);
    cell = [zeros(pad,sz(2)); cell; zeros(pad,sz(2))];
    cell = [zeros(size(cell,1),pad) cell zeros(size(cell,1),pad)];
    
    img = double(img);
    img = [zeros(pad,sz(2)); img; zeros(pad,sz(2))];
    img = [zeros(size(img,1),pad) img zeros(size(img,1),pad)];
    
    % assign the padded area to NaN so that fillmissing can fill those
    % region with the nearest pixels intensity
    img(img==0)=NaN;
    img = fillmissing(img, 'nearest',1);
    img = fillmissing(img, 'nearest',2);        
    
    wn = wnR(1);
    % apply average filter
    avg = conv2(img, ones(wn,wn)/(wn*wn), 'same');
    % find the intensity ratio
    nimg = img./avg;
    % we assume following condition give us true mitochondria and
    % myfabrilis while still many missing which will be recovered by the
    % clusterBasedOnNeighbourhood functon
    seg = (nimg>1.05)+(nimg<0.95)*2+nonCell*3;
    seg(seg>3)=0;
    
    % remove padded area
    cell = cell(pad+1:sz(1)+pad, pad+1:sz(2)+pad);
    img = img(pad+1:sz(1)+pad, pad+1:sz(2)+pad);
    seg = seg(pad+1:sz(1)+pad, pad+1:sz(2)+pad);
    nonCell = nonCell(pad+1:sz(1)+pad, pad+1:sz(2)+pad);
    
    % if image is too big it will take too much time so we defined a
    % threshold value for reducing the size of the image.
    sc = ((numel(img)/1000000)^.5);
    if sc<1  % if image is already small we do not need to do resize.
        sc = 1;
    end
    img2 = img; seg2 = seg; cell2 = cell;
    if sc~=1
        img2 = imresize(img, 1/sc, 'nearest');
        seg2 = imresize(seg, 1/sc, 'nearest');
        cell2 = imresize(cell, 1/sc, 'nearest');
    end
    roi = conv2(double(cell2), ones(15,15),'same')>0;
    conroi = conv2(double(cell2), ones(15,15),'same')==225;
    for i=1:10
        seg2 = clusterBasedOnNeighbourhood(img2, roi, seg2, 20, 20, 1);
        seg2(((seg2>2).*conroi)>0)=0;
        if sum((seg2(:)==0).*cell2(:))==0
            break;
        end
    end
    
    % get the mitochondrian and myofabrilis in the  region of interest that
    % is in the cell area.
    [outCell1, mtch] = findSegBasedConnectivity(seg2==1,cell2);
    [outCell2, myof] = findSegBasedConnectivity(seg2==2,cell2);
    
    if sc~=1
        seg2 = imresize(seg2, sc, 'nearest'); seg2 = seg2(1:sz(1),1:sz(2));
        mtch = imresize(mtch, sc, 'nearest'); mtch = mtch(1:sz(1),1:sz(2));
        myof = imresize(myof, sc, 'nearest'); myof = myof(1:sz(1),1:sz(2));
    end
    
    cell = (mtch|myof).*(~nonCell).*(~zero);        

%     lipid = (nimg<0.75).*cell;

    mtch = (seg2.*cell)==1;
    myof = (seg2.*cell)==2;
    
    seg = mtch*2;
    seg = seg+(myof*3);
end