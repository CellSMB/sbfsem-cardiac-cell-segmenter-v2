function [pks, pkind, lks, lkind] = findPeakLowDf(d, th)
    oriLoc = ones(size(d));
    while length(d)>2
        ln = length(d); mx = max(d);
        [pks, pkind] = findpeaks(d);
        [~, lkind] = findpeaks(mx-d);lks = d(lkind);

        if isempty(pkind)==0 && (isempty(lkind) || lkind(1)>pkind(1))    lks =[d(1);lks]; lkind = [1;lkind]; 
        else                    pks =[d(1);pks]; pkind = [1;pkind]; end
        
        if isempty(lkind)==0 && (isempty(pkind) || lkind(end)>pkind(end))    pks =[pks;d(ln)]; pkind = [pkind;ln];
        else                      lks =[lks;d(ln)]; lkind = [lkind;ln]; end

        loc = [pkind;lkind]; d = [pks;lks];
        [v,ind] = sort(loc); d = d(ind); lc = find(oriLoc==max(oriLoc)); oriLoc(lc(v)) = oriLoc(lc(v))+1;
        ld = abs(conv2(d, [0 1 -1]', 'same')); 
        rd = abs(conv2(d, [-1 1 0]', 'same')); 
        df = min(ld,rd);
        if min(df)>th  break; end
        [v1,ind] = min(df); 
        if ind==1            d = d([2:end]);
        else        d = d([1:ind-1 ind+2:end]); end
        lc = find(oriLoc==max(oriLoc)); 
        if ind==1                   oriLoc(lc(ind)) = oriLoc(lc(ind))-1;
        elseif ind<length(lc)       oriLoc(lc([ind ind+1])) = oriLoc(lc([ind ind+1]))-1; 
        else                        oriLoc(lc(ind)) = oriLoc(lc(ind))-1; end
        
    end
    if length(d)<2  pks = []; pkind = []; lks = []; lkind = []; return; end;
    if length(d)==2 && abs(d(1)-d(2))>th 
        [pks, pkind] = max(d); [lks, lkind] = min(d); 
        lc = find(oriLoc==max(oriLoc)); pkind = lc(pkind); lkind = lc(lkind);
        return; end
    if length(d)==2 && abs(d(1)-d(2))<=th pks = []; pkind = []; lks = []; lkind = []; return; end;
    mx = max(d);
    [pks, pkind] = findpeaks(d);
    [~, lkind] = findpeaks(mx-d);lks = d(lkind);
    if isempty(pkind)==0 && (isempty(lkind) || lkind(1)>pkind(1))    lks =[d(1);lks]; lkind = [1;lkind]; 
    else                    pks =[d(1);pks]; pkind = [1;pkind]; end

    ln = length(d);
    if isempty(lkind)==0 && (isempty(pkind) || lkind(end)>pkind(end))    pks =[pks;d(ln)]; pkind = [pkind;ln];
    else                      lks =[lks;d(ln)]; lkind = [lkind;ln]; end
    lc = find(oriLoc==max(oriLoc)); pkind = lc(pkind); lkind = lc(lkind);
end