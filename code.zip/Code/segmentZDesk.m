function segmentZDesk(myofPath, imgPath, outputPath)
    mkdir(outputPath);
    myof = dir(strcat(myofPath,'\*.tif'));
    for i=1:length(myof)
        disp(sprintf('Segmenting Z-Disc for slice %d of %d',i,length(myof)));
        sln = strsplit(myof(i).name,'.');
        sln = strsplit(sln{1},'_');
%         sln = str2double(sln{end});
        
        img_myof = imread(strcat(myofPath,'\',myof(i).name));
        sz = size(img_myof);
        if sum(img_myof(:)>0)<0.01*sz(1)*sz(2) continue; end
        [path, name, ext] = fileparts(imgPath);
        if isempty(ext)
            img = dir(sprintf('%s\\*%s*.tif',imgPath,sln{end}));
            img_micro = imread(strcat(imgPath,'\',img.name));
        else
            img_micro = imread(imgPath,str2double(sln{end}));
        end
        
        % Keeping only myofabrilis intensity and fill other pixels with the
        % nearest pixels intensity for smoothing the image and comuting
        % intensity ratio
        se = strel('disk',5);
        img = imopen((img_myof>0), se);
        img = double(img_micro).*(img>0);
        img = (img-min(img(img>0)))/(max(img(img>0))-min(img(img>0)))*255.*(img>0);
        img = medfilt2(img,[3 3]).*(img>0);
        F = img; F(img==0)=NaN;
        F = fillmissing(F, 'nearest');
        w = ones(1,50)/50;aimg5 =conv2(F, w, 'same');
        w = ones(1,20)/20;aimg2 =conv2(F, w, 'same');
        z = aimg2./aimg5;
        % the region less than 1 is considered as Z-Disc
        mask = img>0;
        zz= mask.*(z<1);
        zd = imopen(zz,strel('disk',5));
        
%         img_micro = double(img_micro);
%         img2 = 255*img_micro./max(img_micro(:));
%         img1 = img2; img1(zd>0)=255;
%         rgb = cat(3,img1,img2,img2);
%         imwrite(uint8(rgb), strcat('C:\Users\hussain\Desktop\HSD478\2017-09-28-output-cell1_10th\z-disc\xy_',num2str(i,'%04d'),'_z-disc.png'));
        imwrite(zd, strcat(outputPath, '\z_disc_',num2str(i,'%04d'),'.png'));
    end
end