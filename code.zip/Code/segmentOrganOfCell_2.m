function segmentOrganOfCell_2(imageLocation, manualFileLocation, outputFolder, view, slin, wnR, nonCellInt)
    if exist('slin','var')==0   slin = 5;   end    
    slin = slin+5;

    imgFiles = dir(strcat(imageLocation,'*.tif'));
    manFiles = dir(strcat(manualFileLocation,'*.tif'));
    
    cellFileName = strcat('CellArea_',view);mkdir(strcat(outputFolder,'\',cellFileName));
    mitochondriaFileName = strcat('mitochondria_',view);mkdir(strcat(outputFolder,'\',mitochondriaFileName));
    myofibrilsFileName = strcat('myofibrils_',view);mkdir(strcat(outputFolder,'\',myofibrilsFileName));
    blackspotFileName = strcat('blackspot_',view);mkdir(strcat(outputFolder,'\',blackspotFileName));
    t_tabularFileName = strcat('t_tabular_',view);mkdir(strcat(outputFolder,'\',t_tabularFileName));

    lnImgFileName = length(imgFiles(1).name); lnManFileName = length(manFiles(1).name);lnManFiles = length(manFiles);
    nxManFileInd = 1;start = 1;
    problemFiles = []; segIT = 1; lastManSeg = -1;
    for i=1:length(imgFiles)
        if start==1 && strcmpi(manFiles(nxManFileInd).name(lnManFileName-8:end),imgFiles(i).name(lnImgFileName-8:end))==0     continue;   end
        start = 0;
        disp(sprintf('Segmenting Organ in %s view for slice %04d of %04d',view,i,length(imgFiles)));
        img = round(convertZero2One(double(imread(strcat(imageLocation,imgFiles(i).name))))*255);
        % read current (mn_sg) and next (nx_mn_sg) manual segmentation
        if strcmpi(manFiles(nxManFileInd).name(lnManFileName-8:end),imgFiles(i).name(lnImgFileName-8:end))
            mn_sg = conv2(double(imread(strcat(manualFileLocation,manFiles(nxManFileInd).name))>0),ones(slin,slin),'same')>0; 
            if lastManSeg~=i-1  segIT = 1; lastManSeg = i; end
            
            nxManFileInd = nxManFileInd + 1;
            if nxManFileInd>lnManFiles  nxManFileInd = 1;   % this assign of 1 will terminate loop just executing first if condition
            else
                nx_mn_sg = conv2(double(imread(strcat(manualFileLocation,manFiles(nxManFileInd).name))),ones(11,11),'same')>0;
                nx_mn_sg = double(nx_mn_sg)*255;     nx_bw = bwlabel(nx_mn_sg);
            end
        end

        % keep bckup image as we will rescale image for faster processing
        % and get back to the original resolution after segmenting 
        bck_img = img; bck_mn_sg = mn_sg;
        % find the desired scale if image resolution is greater than
        % 2000*800 then we rescale it to 1000*800
        scaleby = size(img);
        if size(img,1)<250
            scaleby(1) = 250;
        end
        if size(img,2)<250
            scaleby(2) = 250;
        end
        if numel(img)>2000*800
            scaleby = ceil(scaleby*(1000*800/numel(img)));
        end

        % resize img, mn_sg and nx_mn_sg
        mn_sg = imresize(mn_sg,scaleby,'nearest');
        if sum(size(mn_sg)==size(nx_mn_sg))<2
            nx_mn_sg = imresize(nx_mn_sg,scaleby,'nearest');
            nx_bw = bwlabel(nx_mn_sg);
        end
        img = imresize(img,scaleby,'nearest');

        % find seperated cell regions in the image
        mn_sg = double(mn_sg>0)*255;     bw = bwlabel(mn_sg);    un = unique(bw(mn_sg>0));    c = histc(bw(:),un);  

        % keep record which slice is not segmentable
        if sum(mn_sg(:)>0)==0      problemFiles = [problemFiles i]; continue;        end
        
        % segIT is used to segment every second slice but ensure that no
        % manually segmented cell slice is not missed
        if segIT == 1
            img = removeBackground_3(img, mn_sg, nx_mn_sg, 0.01);
            seg = zeros(size(img));
            for j=1:length(c)
                if c(j)<(numel(img)/500)            continue;        end
                nx_un = unique(nx_bw(bw==un(j)));nx_un = nx_un(nx_un>0);
                roi = bw==un(j);
                if (sum(roi(:))/numel(roi))<0.001
                    continue;
                end
                seg = max(seg, detectMitoMyofCascadeFilter_2(img, roi, wnR, nonCellInt, slin));
            end
        else
            seg = imresize(seg,scaleby,'nearest');
        end
        segIT =~segIT;
%         close all, figure, imshow(imfuse(img,seg)), title(num2str(i)), drawnow;

        mn_sg = bck_mn_sg;
        % back to original resolution
        seg = imresize(seg,size(mn_sg),'nearest');seg = seg(1:size(mn_sg,1),1:size(mn_sg,2));
        % save images
        imwrite(double(mn_sg), strcat(outputFolder, sprintf('%s\\%s_%04d.tif',cellFileName,cellFileName,i)));
        imwrite(double(seg==2), strcat(outputFolder, sprintf('%s\\%s_%04d.tif',mitochondriaFileName,mitochondriaFileName,i)));
        imwrite(double(seg==3), strcat(outputFolder, sprintf('%s\\%s_%04d.tif',myofibrilsFileName,myofibrilsFileName,i)));
        imwrite(double(seg==4), strcat(outputFolder, sprintf('%s\\%s_%04d.tif',blackspotFileName,blackspotFileName,i)));
        imwrite(double(seg==5), strcat(outputFolder, sprintf('%s\\%s_%04d.tif',t_tabularFileName,t_tabularFileName,i)));
        
        mn_sg = conv2(double(seg>0),ones(slin,slin),'same')>0;
        toc
    end
    problemFiles
end