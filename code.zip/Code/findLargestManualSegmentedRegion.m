function maxInd = findLargestManualSegmentedRegion(imageLocation, ManualSegLocation, st, en, filetype)
    maxArea = 0;
    maxInd = 0;
    for i=st:en
        imgName = dir(strcat(imageLocation,'*',num2str(i),'.',filetype));
        if isempty(imgName)==0  img = imread(strcat(imageLocation,imgName.name));  
        else                continue;   end
        mn_sgName = dir(strcat(ManualSegLocation,'*',num2str(i),'.',filetype));
        if isempty(mn_sgName)==0    mn_sg = double(imread(strcat(ManualSegLocation,mn_sgName.name))>0);
        end
        
        area = sum(sum(mn_sg>0));
        if area>maxArea
            maxArea = area;
            maxInd = i;
        end
    end
end