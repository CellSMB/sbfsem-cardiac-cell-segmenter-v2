function img = convertZero2One(img)
    mn = min(min(min(img)));
    mx = min(max(max(img)));
    if mx==mn && mx>0
        img = img/mx;
    elseif mx>0
        img = (img-mn)/(mx-mn);
    end
end