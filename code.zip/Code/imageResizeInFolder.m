function imageResizeInFolder(path, filetype, scale,outputPath)
    outputPath = strcat(outputPath,'\');
    mkdir(outputPath);
    path = strcat(path,'\');
    files = dir(strcat(path,'*',filetype));
    for i=1:length(files)
        img = imread(strcat(path,files(i).name));
        img = imresize(img,scale,'nearest');
        imwrite(img,strcat(outputPath,files(i).name));
    end
end