function img3D = get3Dimage(inputTiffStackLocation, imgDatatype)
    info = imfinfo(inputTiffStackLocation);
    num_images = numel(info);
    tmp = imread(inputTiffStackLocation, 1);
    img3D = zeros([size(tmp) num_images],imgDatatype);
    for i=1:num_images
        tmp = imread(inputTiffStackLocation, i);
        img3D(:,:,i) = tmp;
    end
end