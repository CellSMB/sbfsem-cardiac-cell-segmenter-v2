function roi = getROIforNucleusBasedEdge(img, connuc)
    img2 = img;
    % apply median filter twice for removing noise
    for i=1:2
        img2 = medfilt2(img2, [5 5]);
    end    
    
    roi = zeros(size(connuc));
    % label seperated nucleus regions
    bw = bwlabel(connuc); un = unique(bw(:)); un = un(un>0);
    
    % compute grdient vertical (grv) and horizontal (grh) direction
    grv = conv2(img2, [1 0 -1]','same');
    grh = conv2(img2, [1 0 -1],'same');
    
    for k = un'
        % take a connected region of nuclues which we defined as confirmed
        b = bw==k;
        [x,y] = find(bw==k);
        minx = min(x); maxx = max(x);
        miny = min(y); maxy = max(y);
        distx = zeros(maxx-minx+1,4)+inf;
        disty = zeros(maxy-miny+1,4)+inf;

        for th = [0.05 0.01]

            ed = edge(img2,'canny',th,2);
            % get border pixels of nucleus in horizontal dirction left border should have positive
            % gradient and right side should have negative gradient
            edt = ed.*(grh>0); edl = ed.*(grh<0);
            for i=minx:maxx
                ln = b(i,:);
                if sum(ln)==0 continue; end
                sn = find(ln,1);
                p11 = find(edt(i,1:sn),1,'last');  p12 = sn-1+find(edt(i,sn:end),1); 
                if abs(sn-p11)>abs(sn-p12) p1 = p12;
                else                       p1 = p11;  end
                rn = find(ln,1,'last');
                p21 = rn-1+find(edl(i,rn:end),1);p22 = find(edl(i,1:rn),1,'last');
                if abs(rn-p21)>abs(rn-p22) p2 = p22;
                else                       p2 = p21;  end
                if isempty(p1) p1 = 1; end
                if isempty(p2) p2 = size(img,2); end
                if distx(i-minx+1,2)>sn-p1  distx(i-minx+1,1) = p1; distx(i-minx+1,2)=sn-p1; end
                if distx(i-minx+1,4)>p2-rn  distx(i-minx+1,3) = p2; distx(i-minx+1,4)=p2-rn; end
            end
            % get border pixels of nucleus in vertical dirction top border should have positive
            % gradient and bottom border should have negative gradient
            edl = ed.*(grv>0); edr = ed.*(grv<0);
            for i=min(y):max(y)
                ln = b(:,i);
                if sum(ln)==0 continue; end
                sn = find(ln,1);
               
                p11 = find(edl(1:sn,i),1,'last');  p12 = sn-1+find(edl(sn:end,i),1); 
                if abs(sn-p11)>abs(sn-p12) p1 = p12;
                else                       p1 = p11;  end
                rn = find(ln,1,'last');
                p21 = rn-1+find(edr(rn:end,i),1);p22 = find(edr(1:rn,i),1,'last');
                if abs(rn-p21)>abs(rn-p22) p2 = p22;
                else                       p2 = p21;  end
                if isempty(p1) p1 = 1; end
                if isempty(p2) p2 = size(img,1); end
                if disty(i-miny+1,2)>sn-p1  disty(i-miny+1,1) = p1; disty(i-miny+1,2)=sn-p1; end
                if disty(i-miny+1,4)>p2-rn  disty(i-miny+1,3) = p2; disty(i-miny+1,4)=p2-rn; end
            end
        end
        % remove outliers from horizontal border
        m = distx(:,[2,4]); m =median(m(:));
        for i=minx:maxx
            if distx(i-minx+1,2)>2*m  distx(i-minx+1,1) = distx(i-minx+1,1) + distx(i-minx+1,2) -m; end
            if distx(i-minx+1,4)>2*m  distx(i-minx+1,3) = distx(i-minx+1,3) - distx(i-minx+1,4) + m; end
            roi(i,distx(i-minx+1,1):distx(i-minx+1,3))=1;
        end
        % remove outliers from vertical border
        m = distx(:,[2,4]); m =median(m(:));
        for i=miny:maxy
            if disty(i-miny+1,2)>2*m  disty(i-miny+1,1) = disty(i-miny+1,1) + disty(i-miny+1,2) -m; end
            if disty(i-miny+1,4)>2*m  disty(i-miny+1,3) = disty(i-miny+1,3) - disty(i-miny+1,4) + m; end
            
            roi(disty(i-miny+1,1):disty(i-miny+1,3),i)=1;
        end
    end
end