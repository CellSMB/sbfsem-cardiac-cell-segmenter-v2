function img3D = get3DimageFromFolder(inputFolderLocation, num_images, imgDatatype, fnOffset)
    if exist('fnOffset','var')==0   fnOffset = 0;   end
    files = [dir(strcat(inputFolderLocation,'\*.tif'));dir(strcat(inputFolderLocation,'\*.png'));dir(strcat(inputFolderLocation,'\*.jpg'));dir(strcat(inputFolderLocation,'\*.jpeg'))];
    tmp = imread(strcat(inputFolderLocation,'\',files(1).name));
    sz = size(tmp);
    img3D = zeros([sz(1:2) num_images],imgDatatype);
    for i=1:length(files)
        img = imread(strcat(inputFolderLocation,'\',files(i).name));
        if size(img,3)>1 img = img(:,:,1); end
        ind = strsplit(files(i).name,'.');ind=ind{length(ind)-1};
        ind = strsplit(ind,'_'); ind = ind{length(ind)};
        num = regexp(ind,'\d');
        ind = fnOffset+str2double(ind(num));
        if ind>num_images break; end
        img3D(:,:,ind) = squeeze(img3D(:,:,ind)) + uint8(convertZero2One(double(img))*255);
    end
end