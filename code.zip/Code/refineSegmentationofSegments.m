function refineSegmentationofSegments(img3D, mito3D, myof3D, cell3D, nucl3D, outputFolder, mitoFolder, myofFolder, cellFolder, maxReg)
    toc
    comn = mito3D & myof3D;
    
    seg = uint8(mito3D) + (uint8(myof3D)*2);    
    seg(comn>0) = 0;
    
    seg = resize3D(seg, 0.5);
    cell= resize3D(cell3D, 0.5);
    img3D = resize3D(img3D, 0.5);
    toc
    disp('Morphological closing and openening operation');
    
    dsk = strel('disk',1);
    for k=3:length(size(seg))
        for i=1:size(seg,k)
            if k==1      img = squeeze(seg(i,:,:));
            elseif k==2  img = squeeze(seg(:,i,:));
            else         img = squeeze(seg(:,:,i));  end

            img1 = img == 1;
            img1 = imclose(imopen(img1,dsk),dsk);
            img2 = img == 2;
            img2 = imclose(imopen(img2,dsk),dsk);
            
            img = double(img1)+double(img2)*2; img(img>2)=0;

            if k==1      seg(i,:,:) = img;
            elseif k==2  seg(:,i,:) = img;
            else         seg(:,:,i) = img;  end
        end
    end
    
    toc
    disp('Filling the segmentation if missing'); 
    
    for k=1:size(img3D,3)
        seg2 = ~cell(:,:,k);
        if sum(seg2(:)==0)<numel(seg2)/1000 continue; end
        img1 = double(img3D(:,:,k));
        th = (mean(img1(seg(:,:,k)==1))+mean(img1(seg(:,:,k)==2)))/2;
        if isnan(th) continue; end
        seg2 = double(seg(:,:,k)) + double(seg2).*((img1>th) + ((img1<=th)*2));
        seg2(seg2>2)=0;
        cl = cell(:,:,k);
        for i=1:5
            seg2 = clusterBasedOnNeighbourhood(double(img3D(:,:,k)), cl, seg2, 20, 20, 0);   
            if sum(seg2(cl>0)==0)==0   break; end
        end
        if sum(seg2(cl>0)==0)>0   
            seg2 = clusterBasedOnNeighbourhood(double(img3D(:,:,k)), cl, seg2, 20, 20, 1); 
        end
        seg(:,:,k) = seg2;
    end
    seg = seg.*uint8(cell);
    toc
    if maxReg==1
        disp('Selecting Connected segment');
        un = unique(seg(:)); un = un(un>0)';
        for j=un
            bw = bwconncomp(seg==j);
            len = zeros(1,bw.NumObjects);    
            for i=1:bw.NumObjects
                t = bw.PixelIdxList{i};
                len(i) = length(t);
            end

            seg(seg==j)=NaN; [v,ind] = max(len);
            seg(bw.PixelIdxList{ind})=j;
        end
    end
    
    for k=1:size(img3D,3)
        if sum(cell(:,:,k)>0)>0 continue; end
        seg2 = seg(:,:,k);
        cl = cell(:,:,k);   
        seg2 = clusterBasedOnNeighbourhood(double(img3D(:,:,k)), cl, seg2, 20, 20, 1); 
        seg(:,:,k) = seg2;
    end
    seg = seg.*uint8(cell);
    
    
    seg = resize3D(seg, 2);
    sz = size(nucl3D);
    seg = seg(1:sz(1),1:sz(2),1:sz(3));
    
    seg(nucl3D>0) = 0;
    toc
    
    disp('Writing output'); 
    mkdir(strcat(outputFolder,cellFolder));
    mkdir(strcat(outputFolder,mitoFolder));
    mkdir(strcat(outputFolder,myofFolder));
    t = 300;
    for i=1:size(cell3D,3)
        cell = double(~(conv2(double(~cell3D(:,:,i)),ones(20,20),'same')>0));
        imwrite(double(cell),sprintf('%s\\%s\\%s_%04d.tif',outputFolder,cellFolder,cellFolder,i));
        imwrite(cell.*double(seg(:,:,i)==1),sprintf('%s\\%s\\%s_%04d.tif',outputFolder,mitoFolder,mitoFolder,i));
        imwrite(cell.*double(seg(:,:,i)==2),sprintf('%s\\%s\\%s_%04d.tif',outputFolder,myofFolder,myofFolder,i));
    end
end