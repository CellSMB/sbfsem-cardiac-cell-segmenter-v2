function seg = clusterBasedOnNeighbourhood(img, roi, seg, wn, strode, intth)
    % we assume in the seg variable 1 is for mitochondria and 2 is for myofabrilis
    % we take a region and the pixels which are not detected to a cluster
    % (either mitochondria or myofabrilis), are defined as a cluster based
    % on the intensity distance. The pixels are assigned to a cluseter
    % which has lowest intensity difference with it 
    un = unique(seg); ln = length(un);
    sz = size(img);
    mnwgtF = inf*ones(sz); mnwgtF(seg>0) = 0;
    bstclF = seg;
    [x,y] = find(roi.*(seg==0));my = [min(y) max(y)];
    for i=min(x):strode:max(x)
        for j=my(1):strode:my(2)
            succ = 0;
            % find out a region where two clusters are present. if intth is
            % 1 then find a region where atleast ten pixels is defined as a
            % cluster. We increase the window size from wn to 3*wn
            for wns=wn:5:min([sz wn*3])
                xen = min(i+wns,sz(1)); yen= min(j+wns,sz(2));
                crs = seg(i:xen,j:yen);
                if sum(crs(:)==0)==0        break;                end
                un2 = unique(crs);
                if sum(ismember(un2,[1 2]))==2
                    fq = histc(crs(:),[1 2]);
                    if sum(fq>10)==2
                        succ = 1;
                    end
                elseif intth==1 && sum(ismember(un2,[1 2]))>0
                    fq = histc(crs(:),[1 2]);
                    if sum(fq>10)>0
                        succ = 1;
                    end
                end
            end
            if succ==0   continue; end
            cri = img(i:xen,j:yen);
            undcd = cri(crs==0); % undecided pixels that is not assigned to a cluster
            mat = [ones(length(undcd),1) undcd];
            mnwgt = inf*ones(length(undcd),1);
            bstcl = zeros(1,length(undcd));
            for k=un(un>0)'
                dcd = cri(crs==k);
                % computing the difference of the intensity with cluster k
                wgt = abs(mat*[-dcd'; ones(1,length(dcd))]);
                wgt = sum(wgt,2)/size(wgt,2);
                mnwgt = min(mnwgt,wgt);
                bstcl(mnwgt==wgt) = k;
            end
            
            tmpcl = bstclF(i:xen,j:yen);tmpcl = tmpcl(:);
            tmpwgt = mnwgtF(i:xen,j:yen);tmpwgt=tmpwgt(:);
            tmp = min(tmpwgt(crs==0),mnwgt);
            tmp = tmp==mnwgt;
            ind = find(crs(:)==0);
            tmpcl(ind(tmp>0)) = bstcl(tmp>0);
            tmpwgt(ind(tmp>0)) = mnwgt(tmp>0);
            bstclF(i:xen,j:yen) = reshape(tmpcl, [xen-i+1,yen-j+1]);
            mnwgtF(i:xen,j:yen) = reshape(tmpwgt, [xen-i+1,yen-j+1]);
        end
    end
    seg = bstclF;
end