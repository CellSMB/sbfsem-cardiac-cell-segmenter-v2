function [img, eqIn] = EqualizeIntensityinSlice(img, refImg, refy, refx, eqIn)
    sz = size(img);
    % apply wiener filter
    img = wiener2(img, [5 5]);
    % find mean and standard eviation of the image
    mn = mean(img(img>0)); sd = std(double(img(img>0)));
    % find the range of intensity
    lwB = mn-sd; upB = mn+sd;
    i = 0;
    ind = sub2ind(size(img),refx,refy); x = refx;
    % find the valid cell region, sometimes adjacent slice does not have
    % cell due to acquisition process 
    brk1 = 0; brk2 = 0;
    while 1==1
        y = refy-i; vld = y>0 & y<sz(2); 
        if sum(vld) brk1 = 1;    end
        x = refx(vld); y = y(vld);
        ind2 = sub2ind(sz,x,y);
        if sum(img(ind2)>0)>sum(refImg(ind)>0)*0.8  break;  end
        y = refy+i; vld = y>0 & y<sz(2); 
        if sum(vld) brk2 = 1;    end
        x = refx(vld); y = y(vld);
        ind2 = sub2ind(sz,x,y);
        if sum(img(ind2)>0)>sum(refImg(ind)>0)*0.8  break;  end
        i = i+1;
        if brk1+brk2==2 img = uint16(img); return;  end
    end
    
    rfx = x; rfy = y;ind = ind2;i = 0;
    refLine = refImg(ind);
    
    % maximum acceptptable intensity threshold
    tol = 2*max(max(img))/255;
    
    % refLine(abs(refLine-lwB)<abs(refLine-upB)) = 0;
    
    % eqln is the target intensity of a line
    if exist('eqIn','var')==0 eqIn = mean(refLine(refLine>tol));    end
    
    while 1==1
        y = y-i;vld = y>0 & y<sz(2); 

        if sum(vld)==0 || sum(refLine)==0
            if i==1 i=-1; x = rfx;  y = rfy;   refLine = refImg(ind); continue; end
            break;    
        end
        if i == 0 i =1; end
        x = x(vld>0); y = y(vld>0);  refLine = refLine(vld>0); 
        ind2 = sub2ind(sz,x,y);        line = img(ind2);  line(abs(line-lwB)<abs(line-upB)) = 0;
        vld = (refLine>tol & line>tol);   
        if sum(vld)==0  continue;   end
        % add difference between reference intensity (eqln) and original
        % intensity
        img(ind2) = img(ind2) + round(eqIn - mean(line(vld)));                    
        refLine = img(ind2);
    end 
    img = uint16(img);
end