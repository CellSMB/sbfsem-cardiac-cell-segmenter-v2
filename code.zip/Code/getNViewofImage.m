function getNViewofImage(img3D, outputFolderLocation, filePrefix, n, manual, range) 
    mkdir(outputFolderLocation);
    if exist('range','var')==0
        range = 1:size(img3D, n);
    else
        range = range(range>=1); range = range(range<=size(img3D, n));
        if size(range,1)>1 range = range'; end
    end
    if exist('manual','var')==0
        manual = 0;
    end
    for i=range
        if n==1 tmp = img3D(i,:,:);
        elseif n==2 tmp = img3D(:,i,:);
        elseif n==3 tmp = img3D(:,:,i);   end
        tmp = squeeze(tmp);
%         tmp = round(convertZero2One(double(tmp))*255);
        if manual>0 && sum(sum(tmp>0))==0  continue;   end
        if manual>0   tmp = tmp*255;    end
        imwrite(uint8(tmp),sprintf('%s\\%s_%04d.tif',outputFolderLocation,filePrefix,i),'tif');
    end
end