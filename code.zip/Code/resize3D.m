function imOut = resize3D(im, sc)
sz = size(im);

imOut = [];

for i=1:sz(3)
    imOut = cat(3,imOut,imresize(im(:,:,i),sc, 'nearest'));
end