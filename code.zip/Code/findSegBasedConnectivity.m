function [outCell, inCell] = findSegBasedConnectivity(seg,roi)
    % determine segmented region in or out of the cell using roi. To do it,
    % we apply conv with 1 to 15 window and reduce the regions. After that
    % we compute the area of segmented region in the roi. if it matched the
    % condition we keep it as true segmentation and inside of the cell.
    % otherwise go to the next iteration.
    outCell = zeros(size(roi));
    inCell = zeros(size(roi));
    refROI = roi;
    
    for i=1:2:15
        pot_mtch2 = conv2(double(seg), ones(i,i), 'same')==i*i;
        bw = bwlabel(pot_mtch2); 
        un = unique(bw.*refROI); un = un(un>0);
        bw = bw.*ismember(bw,un);        
        outCell = outCell | ((seg-refROI-(seg.*(conv2(double(bw), ones(i,i),'same')>0)))>0);
        out = (~refROI).*bw; un = unique(out);
        inCell = inCell | (seg.*(conv2(double(((bw>0)-ismember(bw,un))>0),ones(i,i),'same')>0));
        if length(un)==1  break;  end
        un = un(un>0);
        [c,b] = histc(bw.*ismember(bw,un),un); c = sum(c,2);
        [co,b] = histc(out,un); co = sum(co,2);
        r = co./c;
        coa = []; ca = [];
        for k=un'
            [x,y] = find(out==k);
            coa = [coa; (max(x)-min(x)+1)*(max(y)-min(y))];
            [x,y] = find(bw==k);
            ca = [ca; (max(x)-min(x)+1)*(max(y)-min(y))];
        end
        ra =coa./ca;
        try
            inCell = inCell | (seg.*(conv2(double(ismember(bw,un(ra<.10 & r<.30 & [log(co)/log(5)]<(i+1)))), ones(i,i), 'same')>0));
        catch
            k
        end        
        refROI = refROI | inCell;
    end
    inCell = seg - outCell;
end