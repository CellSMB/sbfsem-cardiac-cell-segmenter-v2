function seg3D = refineSegmentationBasedOn3View_2(inputFolder, filePrefix, img3DSize, nucleus, maxReg)
    % get 3D image and defined a pixels as a true segmentation if it is
    % segmented as true atleast in two direction and XY, XZ and YZ
    seg3D = zeros(img3DSize,'uint8');
    
    inputFolderXY = strcat(inputFolder,filePrefix,'_xy\');
    inputFolderXZ = strcat(inputFolder,filePrefix,'_xz\');
    inputFolderYZ = strcat(inputFolder,filePrefix,'_yz\');
    
    files = dir(strcat(inputFolderXY,'*.tif'));
    for i=1:length(files)
        img = imread(strcat(inputFolderXY,files(i).name))>0;
        ind = strsplit(files(i).name,'.');ind=ind{1};
        ind = strsplit(ind,'_');ind = str2double(ind{length(ind)});
        seg3D(:,:,ind) = squeeze(seg3D(:,:,ind)) + (uint8(img)*2);
    end

    files = dir(strcat(inputFolderXZ,'*.tif'));
    for i=1:length(files)
        img = imread(strcat(inputFolderXZ,files(i).name))>0;
        ind = strsplit(files(i).name,'.');ind=ind{1};
        ind = strsplit(ind,'_');ind = str2double(ind{length(ind)});
        seg3D(:,ind,:) = squeeze(seg3D(:,ind,:)) + (uint8(img)*3);
    end

    files = dir(strcat(inputFolderYZ,'*.tif'));
    for i=1:length(files)
        img = imread(strcat(inputFolderYZ,files(i).name))>0;
        ind = strsplit(files(i).name,'.');ind=ind{1};
        ind = strsplit(ind,'_');ind = str2double(ind{length(ind)});
        seg3D(ind,:,:) = squeeze(seg3D(ind,:,:)) + (uint8(img)*4);
    end

    seg3D = seg3D>4;
    seg3D = (seg3D - nucleus)>0;
    
%     dsc = strel('disk',1);
%     for k=1:length(size(seg3D))
%         for i=1:size(seg3D,k)
%             if k==1     img = squeeze(seg3D(i,:,:)); 
%             elseif k==2 img = squeeze(seg3D(:,i,:)); 
%             elseif k==3 img = squeeze(seg3D(:,:,i)); end
%             
%             img = imopen(imclose(img,dsc),dsc);
%             
%             if k==1     seg3D(i,:,:) = img; 
%             elseif k==2 seg3D(:,i,:) = img; 
%             elseif k==3 seg3D(:,:,i) = img; end
%         end
%     end
%     
%     if maxReg==1
%         bw = bwconncomp(seg3D);
%         len = zeros(1,bw.NumObjects);    
%         for i=1:bw.NumObjects
%             t = bw.PixelIdxList{i};
%             len(i) = length(t);
%         end
% 
%         seg3D = seg3D==2; [v,ind] = max(len);
%         seg3D(bw.PixelIdxList{ind})=1;
%     end
    
    
    
%     mkdir(outputFolder);
%     for i=1:size(seg3D,3)
%         imwrite(double(squeeze(imopen(imclose(seg3D(:,:,i),strel('disk',5)),strel('disk',5)))),sprintf('%s\\%s_%04d.tif',outputFolder,filePrefix,i));
%     end
end