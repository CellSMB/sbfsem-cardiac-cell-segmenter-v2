tic

inputFolder = strcat(inputFolder,'\');
outputFolder = strcat(outputFolder,'\');

% transform tiff stack to Files of original images in 3 view
disp('Start Reading Image Stack');
if exist(fname,'file')>0     infld = '';
else                         infld = inputFolder; end
if exist(strcat(infld,fname),'file')==0
    disp(strcat('Images are not found in ',strcat(infld,fname)));
    return;
end
if exist(strcat(infld,fname),'file')==7 % 7 means folder
    img3D = get3DimageFromFolder(strcat(infld,fname),numberOfScan,'uint8', filename_offset);
else
    img3D = get3Dimage(strcat(infld,fname),'uint16');
end
toc

if scaleBy~=1
    disp('Start scaling');
    originalSize = size(img3D);
    img3D = resize3D(img3D, scaleBy);
    if normalizeDirection~=3  
        BestScanPosition = round(BestScanPosition*scaleBy);
        acquiringLine([1,3]) = acquiringLine([1,3])*scaleBy;
    else
        acquiringLine = round(acquiringLine*scaleBy);
    end
    
    
    toc
end

numberOfScan = size(img3D,3);

disp('Start transfoming intensity from 0 to 255');
[img3D, mn, mx] = transform0to255(img3D);
nonCellInt = 255*(nonCellInt-double(mn))/double(mx);
backgroundIntensity = 255*(backgroundIntensity-double(mn))/double(mx);

% our method assume mitochondria has higher intensity than myofabrilis
if isMitochondriaHasHigherIntensity==0    
    img3D = 255-img3D;
    nonCellInt = 255-nonCellInt;
    backgroundIntensity = 255-backgroundIntensity;
end
toc

disp('Start Noise Reduction');
img3D = medfilt3(img3D);
if BestScanPosition>0       % if BestScanPosition is assigned more than 0 that means now image need normalization
    img3D = EqualizeIntensity(img3D, normalizeDirection, BestScanPosition, acquiringLine, backgroundIntensity, strcat(outputFolder,'EqualizeInten\'));
end
% img3D = medfilt3(img3D);
toc

disp('Start saving image in XY angle');
getNViewofImage(img3D,strcat(outputFolder,'image_xy\'),'image_xy',3);
toc
disp('Start saving image in XZ angle');
getNViewofImage(img3D,strcat(outputFolder,'image_xz\'),'image_xz',2);
toc
disp('Start saving image in YZ angle');
getNViewofImage(img3D,strcat(outputFolder,'image_yz\'),'image_yz',1);
toc

disp('Start Reading Manual Segmentation');
if exist(manualSeg,'file')>0 infld = '';
else                         infld = inputFolder; end
if exist(strcat(infld,manualSeg),'file')==0
    disp(strcat('Manual Segmentation of Cell boundaries are not found in ',strcat(infld,manualSeg)));
    return;
end
if exist(strcat(infld,manualSeg),'file')==7 % 7 means folder
    img3D = get3DimageFromFolder(strcat(infld,manualSeg),numberOfScan,'uint8', filename_offset);manual = 1;
else
    img3D = get3Dimage(strcat(infld,manualSeg),'uint8');manual = 1;
end
toc
if scaleBy~=1
    disp('Start scaling');
    img3D = resize3D(img3D, scaleBy);
    toc
end
disp('Start removing Manual Segmenation if required');
img3D = blankSomeIntermediateScans(img3D, manSegInterval);% remove some manual segmentation if you want with a certain periodic interval
toc
disp('Start saving image in XY angle');
getNViewofImage(img3D,strcat(outputFolder,'ManualCell_xy\'),'ManualCell_xy',3,manual);
toc
disp('Start saving image in XZ angle');
getNViewofImage(img3D,strcat(outputFolder,'ManualCell_xz\'),'ManualCell_xz',2,manual);
toc
disp('Start saving image in YZ angle');
getNViewofImage(img3D,strcat(outputFolder,'ManualCell_yz\'),'ManualCell_yz',1,manual);
toc

if isempty(manualNuc)==0 && length(manualNuc)>0
    disp('Start Reading Manual Segmentation for Nucleus');
    if exist(manualNuc,'file')>0 infld = '';
    else                         infld = inputFolder; end
    if exist(strcat(infld,manualSeg),'file')==0
        disp(strcat('Manual Segmentation of Nucleus are not found in ',strcat(infld,manualNuc)));
        return;
    end
    if exist(strcat(infld,manualNuc),'file')==7 % 7 means folder
        img3D = get3DimageFromFolder(strcat(infld,manualNuc),numberOfScan,'uint8', filename_offset);manual = 1;
    else
        img3D = get3Dimage(strcat(infld,manualNuc),'uint8');manual = 1;
    end   
    
    if scaleBy~=1
        disp('Start scaling');
        img3D = resize3D(img3D, scaleBy);
        toc
    end
    
    disp('Start saving image in XY angle');
    getNViewofImage(img3D,strcat(outputFolder,'ManualNucleus_xy\'),'ManualNucleus_xy',3,manual);
    
    disp('Start segmenting Nucleus');
    segmentNucleus_2(strcat(outputFolder,'image_xy\'), strcat(outputFolder,'ManualNucleus_xy\'), strcat(outputFolder,'AutomaticNucleus_xy\'), 'AutomaticNucleus_xy', 'tif');
    % get 3D image from image slices from a folder
    nucleus = reformFullImageStackFromImageFile(strcat(outputFolder,'AutomaticNucleus_xy\'), 'tif', size(img3D), 3, 'logical');
    toc
else
    nucleus = zeros(size(img3D),'logical');
end

segmentOrganOfCell_2(strcat(outputFolder,'image_xy\'), strcat(outputFolder,'ManualCell_xy\'), outputFolder, 'xy', manSegInterval, wnR, nonCellInt);
toc
segmentOrganOfCell_2(strcat(outputFolder,'image_xz\'), strcat(outputFolder,'ManualCell_xz\'), outputFolder, 'xz', manSegInterval, wnR, nonCellInt);
toc
segmentOrganOfCell_2(strcat(outputFolder,'image_yz\'), strcat(outputFolder,'ManualCell_yz\'), outputFolder, 'yz', manSegInterval, wnR, nonCellInt);
toc

toc
disp('Refine Segmentation')
disp('Reading image');
img3D = get3DimageFromFolder(strcat(outputFolder,'image_xy/'),numberOfScan,'uint8', 0);
toc
if exist(strcat(outputFolder,'AutomaticNucleus_xy/'),'file')>0
    disp('Reading Segmented Nucleus');
    nucleus = get3DimageFromFolder(strcat(outputFolder,'AutomaticNucleus_xy/'),numberOfScan,'uint8', 0);
    nucleus = nucleus>0;
else
    nucleus = zeros(size(img3D));
end

toc
disp('Reading Segmented CellArea');
filePrefix='CellArea';
cell3D = refineSegmentationBasedOn3View_2(outputFolder, filePrefix, size(img3D), zeros(size(nucleus),'logical'), 1);
toc
disp('Reading Segmented mitochondria');
filePrefix='mitochondria';
mito3D = refineSegmentationBasedOn3View_2(outputFolder, filePrefix, size(img3D), nucleus, 1);
toc
disp('Reading Segmented myofibrils');
filePrefix='myofibrils';
myof3D = refineSegmentationBasedOn3View_2(outputFolder, filePrefix, size(img3D), nucleus, 1);
cellFolder = 'CellArea'; mitoFolder = 'mitochondria'; myofFolder = 'myofibrils';
toc
disp('Final Refinement');
refineSegmentationofSegments(img3D, mito3D, myof3D, cell3D, nucleus, outputFolder, mitoFolder, myofFolder, cellFolder, 1);
toc
disp('Segment Z-Disc')
segmentZDesk(strcat(outputFolder,myofFolder,'\'), strcat(outputFolder,'\image_xy\'), strcat(outputFolder,'\Z_disc\'));
toc
if scaleBy~=1
    disp('back to original resolution');
    imageResizeInFolder(strcat(outputFolder,myofFolder,'\'), 'tif', originalSize(1:2),strcat(outputFolder,myofFolder,'-oriResolution\'));
    imageResizeInFolder(strcat(outputFolder,mitoFolder,'\'), 'tif', originalSize(1:2),strcat(outputFolder,mitoFolder,'-oriResolution\'));
    imageResizeInFolder(strcat(outputFolder,cellFolder,'\'), 'tif', originalSize(1:2),strcat(outputFolder,cellFolder,'-oriResolution\'));
    imageResizeInFolder(strcat(outputFolder,'AutomaticNucleus_xy/'), 'tif', originalSize(1:2),strcat(outputFolder,'AutomaticNucleus_xy-oriResolution/'));
end
toc