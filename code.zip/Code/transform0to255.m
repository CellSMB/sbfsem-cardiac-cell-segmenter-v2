function [img, mn, mx] = transform0to255(img)
    mn = min(min(min(img)));
    mx = max(max(max(img)));
    for i = 1:size(img,3)
        img(:,:,i) = uint16(round(double(img(:,:,i)-mn)*255/double(mx-mn)));
    end
end