function img3D = blankSomeIntermediateScans(img3D, manual)
    c = 0;st=1;lt = 0;pscN = 0;
    for i=1:size(img3D,3)        
        if sum(sum(img3D(:,:,i)))>0                         
            if pscN == 0 pscN = i; continue; end        
            if i-pscN<manual         img3D(:,:,i) = 0;  continue;             end      
            if ((i-pscN)/manual)>1.5  
                anss = questdlg('There are some manual segmentation missing. Do you want to fix it by interpolation?','Consent About Fixing manual Segmentation.');
                if strcmpi(anss,'yes')
                    for j = pscN+manual:manual:i-(manual/2)
                        img3D(:,:,j) = img3D(:,:,pscN);
                    end
                end
            end
            pscN = i;
        end
    end
end