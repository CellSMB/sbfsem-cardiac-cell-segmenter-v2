function nonCell = getNonCellRegion(img, intR)
    % find the non cell region using a threshold value which is defined by
    % histogram analysis. We consider the peak intensity information to
    % defined the range of intensity for the non cell region.
    img = uint8(conv2(double(img),ones(5,5)/25,'same'));
    un = unique(img); fq = histc(img(:),un);
    for dn = 100:100:500
        th = (max(fq(2:end))-min(fq))/dn;
        [pks, pkind, lks, lkind] = findPeakLowDf(fq, th);
        if size(intR,1)>1  intR = intR'; end
        if isempty(pks)  continue; end
        dst = abs(double([ones(length(pkind),1) un(pkind)]) * [-intR; ones(1,length(intR))]);
        [x,y] = find(dst==min(dst(:)),1);
        if x<length(lkind)
            break;
        end
    end
    if isempty(pks)
        nonCell = ones(size(img)); return;
    end
    if x>length(lkind)
        mx = un(pkind(x));
    elseif lkind(x)>pkind(x)
        mx = un(lkind(x));
    elseif length(lkind)>x 
        mx = un(lkind(x+1));
    else
        mx = un(end);
    end
    
    if mx>(intR(end)+2*(intR(end)-intR(1)))
        mx = (2*intR(end)-intR(1));
    end
    
    mn = un(1);
    
    nonCell = img>=mn & img<=mx;
end