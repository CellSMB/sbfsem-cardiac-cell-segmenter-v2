function [img, nonCell] = detectNonCell_2(img, cell)
    img(img==0)= max(img(:));
    img = (255-img);
    cell2 = conv2(double(cell),ones(20,40),'same')>0;
    b = sort(img(cell2>0 & img>0));
    np = sum(sum(cell));
    if isempty(b)
        nonCell = zeros(size(img));
        return;
    end
    l = length(b);
    for i=1:10
       
        nonCell = img>b(min(l,round(np*i/2)));
        if sum(sum(nonCell.*cell)) < 0.3*np
            break;
        end
    end
    nonCell = (nonCell-cell)>0;
end