function img = keepOnlyMytoMyof(img, roi)
    % Smooth the image except potential mitochondria and myofabrilis regions. 
    un = unique(img(roi>0)); fqo = histc(img(roi>0),un);
    dn=10; fq = conv(fqo,ones(round(length(fqo)/dn),1),'same');
    th = (max(fq)-min(fq))/10;
    % find the threshold value from the peak of the intensities for finding
    % non mitochondria and myofabrilis regions
    for i=1:10
        [pks, pkind, lks, lkind] = findPeakLowDf(fq, th);
        if length(pks)<2 && th>2
            th = max(th/10,2);
        elseif length([pks;lks])>3  break;  
        else
            dn = round(dn/2);
            fq = conv(fqo,ones(round(length(fqo)/dn),1),'same');
            th = (max(fq)-min(fq))/10;
        end
    end
    in = [pkind;lkind]; [in,ind] = sort(in);
    vl = [pks;lks]; vl = vl(ind);
    [v,ind] = sort(vl,'descend');
    if isempty(ind) img = []; return; end
    if ind(1)>ind(2)        ind = ind(2);
    else                    ind = ind(1);  end
    if ind>1
        th = un(in(ind-1));
    else
        th = 2*un(in(ind)) - un(in(ind+1));
    end
    % find the dark region (non mitochondria and myofabrilis area) and replace with the median value
    drk = (roi.*(img<th))>0;  
    img(drk>0)=un(in(ind));
    avg = conv2(img, ones(10,10)/100,'same');
    img(drk>0)=avg(drk>0);
    if ind<length(in)
        th = un(in(ind+1));
    else
        th = 2*un(in(ind)) - un(in(ind-1));
    end
    med = medfilt2(img, [5,5]);
    drk = (roi.*(img<th))>0;  
    img(drk>0)=med(drk>0);
end