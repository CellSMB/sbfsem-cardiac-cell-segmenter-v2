function img = removeBackground_3(img, roi, nextRoi, th)
    if sum(roi(:)==0)<numel(roi)/100
        return;
    end
    sz = size(img);
    roi = roi>0;
    nextRoi = nextRoi>0;
    %remove background of image and get ROI (roi_2) for the cell.
    edg = edge(img,'canny',th);
    [v,firstEdg] = max(edg); [ind1,ind2] = max(firstEdg.*v.*(firstEdg <(sz(1)/2)));
    int = median(img(1:ind1,ind2));
%     int = median(img(sub2ind(sz,find(v),firstEdg(v>0))));
    edg = edg | (img<(int-5));
    mn = min(min(img((roi|nextRoi)>0)));
    if isempty(mn)
         img = zeros(size(img));
         return;
    end
    oriImg = img;
    for i=1:size(img,2)
        a = edg(:,i);
        ind = find(a,1);
        if isempty(ind)
            img(:,i)=0;
        else
            v = find(oriImg(ind:end,i)~=oriImg(ind,i),1)-2;
            if isempty(v)==0 && v>0 
                ind = ind+v;  
            end
                
            img(1:ind,i)=0;img(ind:min(ind+2,sz(1)),i)=mn;
            if i>1
                img(img(1:ind,i-1)>0,i-1)=mn;
            end
            if i<sz(2)
                img(img(1:ind,i+1)>0,i+1)=mn;
            end
            ind = find(a,1,'last');img(ind:end,i)=0;img(max(1,ind-2):ind,i)=mn;
            if i>1
                img(ind-1+find(img(ind:end,i-1)>0),i-1)=mn;
            end
            if i<sz(2)
                img(ind-1+find(img(ind:end,i+1)>0),i+1)=mn;
            end
        end
    end    
end